package com.itbulls.learnit.onlinestore.core.services;

public interface Validator {
	
	boolean isValid(String stringValue);

}
