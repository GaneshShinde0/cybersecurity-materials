package com.itbulls.learnit.onlinestore.core;

public interface CoreConfigurations {

	Double REFFERER_REWARD_RATE = 0.02; // 2%
	
}
