package com.itbulls.learnit.onlinestore.core.services;

public interface AffiliateMarketingService {
	
	String generateUniquePartnerCode();

}
