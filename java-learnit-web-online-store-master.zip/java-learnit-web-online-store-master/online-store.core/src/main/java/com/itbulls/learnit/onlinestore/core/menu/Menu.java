package com.itbulls.learnit.onlinestore.core.menu;

public interface Menu {
	
	String RESOURCE_BUNDLE_BASE_NAME = "exam.labels";

	void start();
	
	void printMenuHeader();
}
