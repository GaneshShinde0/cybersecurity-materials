This is repository with the source code for Java course by Andrii Piatakha.
It is not allowed to copy code and any commercial use (for example in other learning courses etc) without written approval from Andrii Piatakha.

Only students of Andrii Piatakha can use these code examples. 
Thanks for respecting hard work of the author.

Deployment algorithm:
-
- Import your porject into IDE
- Create the database that is called 'learn_it_db', or change the URL to the database in the com.itbulls.learnit.onlinestore.persistence.utils.connectionpools.DbcpDemo class
- Make sure that the user name of your DB user is "root" and password is "root", or change those in DbcpDemo class
- Import database by running scripts from the "database-export" folder from the persistence module
- Start the application. You can start the web module.
- Use the application

2019© Andrii Piatakha


