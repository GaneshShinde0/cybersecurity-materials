package com.itbulls.learnit.onlinestore.persistence.enteties;

public enum Priority {
	LOW, MEDIUM, HIGH;
}
