package com.itbulls.learnit.onlinestore.persistence.dao;

import com.itbulls.learnit.onlinestore.persistence.dto.PurchaseStatusDto;

public interface PurchaseStatusDao {

	PurchaseStatusDto getPurchaseStatusById(Integer id);

}
