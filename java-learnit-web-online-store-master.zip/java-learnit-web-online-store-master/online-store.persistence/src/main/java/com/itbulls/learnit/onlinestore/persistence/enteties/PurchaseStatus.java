package com.itbulls.learnit.onlinestore.persistence.enteties;

public interface PurchaseStatus {

	void setId(Integer id);

	void setStatusName(String statusName);

	Integer getId();

	String getStatusName();

}
