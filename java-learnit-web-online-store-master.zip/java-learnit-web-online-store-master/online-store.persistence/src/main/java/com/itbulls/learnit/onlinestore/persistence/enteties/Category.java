package com.itbulls.learnit.onlinestore.persistence.enteties;

public interface Category {
	
	Integer getId();
	String getCategoryName();
	
}
