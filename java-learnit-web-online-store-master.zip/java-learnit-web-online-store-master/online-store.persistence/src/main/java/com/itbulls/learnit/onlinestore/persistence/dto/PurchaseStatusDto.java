package com.itbulls.learnit.onlinestore.persistence.dto;

public class PurchaseStatusDto {
	
	private Integer id;
	private String statusName;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}



}
