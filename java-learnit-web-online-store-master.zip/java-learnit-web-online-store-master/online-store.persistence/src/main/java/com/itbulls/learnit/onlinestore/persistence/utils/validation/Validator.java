package com.itbulls.learnit.onlinestore.persistence.utils.validation;

public interface Validator {
	
	boolean isValid(Object obj);

}
